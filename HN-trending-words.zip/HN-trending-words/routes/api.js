var express = require('express');
var router = express.Router();

const fs = require("fs");

router.get('/words', function (req, res, next) {
    res.json(JSON.parse(fs.readFileSync('HN/trending.words.json').toString()));

});

module.exports = router;
