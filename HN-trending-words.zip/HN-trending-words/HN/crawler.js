const debug = require('debug')('hn-trending-words:Crawler');
const axios = require('axios');
const cheerio = require('cheerio');
const _ = require('lodash');
const fs = require("fs");

async function crawler() {
    debug('Crawler of Hacker News works every 30 minutes 👀');
    let words = {}, page = 1;
    while (true) {
        const url = `https://news.ycombinator.com/news?p=${page++}`
        debug(`Fetching page: ${url}`);
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);
        const titles = $('a.storylink');
        if (!titles.length) {
            break;
        }
        titles.each(function () {
            const title = $(this).text();
            let href = $(this).attr('href');
            if (!href.startsWith('http')) { // If not an external link
                href = `https://news.ycombinator.com/${href}`;
            }
            // use regex to get the words in the title, eg: 5G, 4M, 21st are words, a, 1000 aren't words
            title.match(/\w{1,}[A-Za-z]/g).forEach((word) => {
                let value = words[word];
                if (!value) {
                    value = {frequency: 1, list: [{title, href}]};
                    words[word] = value;
                } else {
                    value.frequency++;
                    value.list.push({title, href});
                }
            })
        })
    }
    let trendingWords = [];
    for (const word in words) {
        let {frequency, list} = words[word];
        if (frequency > 2) { // only the words appears more than 2 times
            // maybe the same word appears in a title more than once, so use _.uniqBy to remove duplicate links
            trendingWords.push({word, frequency, list: _.uniqBy(list, 'href')});
        }
    }
    // sort by frequency in descending order.
    trendingWords.sort((a, b) => b.frequency - a.frequency);
    // Beautify and save the trending words in a file
    let prettyContent = JSON.stringify(trendingWords, null, 4);
    const filename = 'HN/trending.words.json';
    fs.writeFileSync(filename, prettyContent, {flag: 'w'});
    debug(`${filename} is updated at ${new Date}`)
}

crawler();
setInterval(crawler, 30 * 60 * 1000); // update the trending words every 30 minutes 👀