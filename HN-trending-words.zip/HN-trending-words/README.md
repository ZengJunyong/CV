## How to run?
1. npm install
2. DEBUG=hn-trending-words:* npm start 
Note: in the step 2: **npm start** is OK but you won't see see log in the terminal.

## JSON
I just noticed you defined the json today (at May 5), but I have finished this test, a bit different with yours, mine is
```json
[
    {
        "word": "to",
        "frequency": 79,
        "list": [
            {
                "title": "Mathics – A free, light-weight alternative to Mathematica",
                "href": "https://mathics.github.io/"
            },
            ...
        ]
    },
    ...
]
```

## bootstrapped project
I used https://expressjs.com/en/starter/generator.html to generator a SIMPLE application skeleton. less than 10 files in this project.

Files I added:
1. **HN/crawler.js** the core code for the backend. the trending words are saved in a file called **HN/trending.words.json**.
2. **routes/api.js** the API service, just response the generated file
3. **public/index.html, public/stylesheets/style.scss, public/javascripts/trending.words.js** these 3 files are used to build the frontend. I just kept as simple as possible. imported vue, axios from CDN.

Files I modified 
1. **app.js** changed a bit, for example call **HN/crawler.js** when the backend starts
2. **packages.json** basically I added libraries like: axios, cheerio, lodash... actually this file is generated automatically when I used **npm install --save XXX**

More details? use **git log** to check more :-)