/**
 * TODO: async/await is part of ECMAScript 2017 and is not supported in Internet Explorer and older browsers,
 * so need to change it to the lower javascript version if in REAL project.
 */
(async function () {
    const {data} = await axios.get('api/words');
    new Vue({
        el: '#app',
        data: {
            words: data,
            isStoriesVisible: false,
            selectedWord: null
        },
        methods: {
            showStories(item) {
                this.selectedWord = item;
                this.isStoriesVisible = true;
            }
        }
    })
})();